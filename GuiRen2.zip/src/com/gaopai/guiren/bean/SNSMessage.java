package com.gaopai.guiren.bean;

import java.io.Serializable;

public class SNSMessage implements Serializable{
	private static final long serialVersionUID = -2673209049472192244L;
}
