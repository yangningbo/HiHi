package com.gaopai.guiren.bean;

import java.io.Serializable;

import com.gaopai.guiren.bean.net.BaseNetBean;

public class CheckUpdateResult extends BaseNetBean implements Serializable {
	
	public Version data;
}
