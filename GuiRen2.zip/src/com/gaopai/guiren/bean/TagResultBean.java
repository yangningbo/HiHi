package com.gaopai.guiren.bean;

import java.util.List;

import com.gaopai.guiren.bean.net.BaseNetBean;

public class TagResultBean extends BaseNetBean{
	public List<TagBean> data;

}
