package com.gaopai.guiren.bean;

import java.io.Serializable;

public class BaseInfo implements Serializable{
	private static final long serialVersionUID = -114654654654653L;
	
	public String screenName;
	public String headimgUrl;
	public String mGender = "0";
}
