package com.gaopai.guiren.bean;

public class MessageState {
	public static final int STATE_SEND_SUCCESS = 1;
	public static final int STATE_SEND_FAILED = 0;
	
	public static final int STATE_SENDING = 2;
	public static final int STATE_DOWNLOADING = 4;
	
	public static final int VOICE_READED = 1;
	public static final int VOICE_NOT_READED = 0;
	
	
	public static final int MESSAGE_SHIDE = 1;
	public static final int MESSAGE_NOT_SHIDE = 0;
	
	

}
