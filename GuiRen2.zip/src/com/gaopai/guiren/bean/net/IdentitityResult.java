package com.gaopai.guiren.bean.net;

import com.gaopai.guiren.bean.AppState;
import com.gaopai.guiren.bean.Identity;

public class IdentitityResult {
	public Identity data;
	public AppState state;
}
