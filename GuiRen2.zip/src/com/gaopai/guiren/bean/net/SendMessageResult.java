package com.gaopai.guiren.bean.net;

import com.gaopai.guiren.bean.AppState;
import com.gaopai.guiren.bean.Identity;
import com.gaopai.guiren.bean.MessageInfo;

public class SendMessageResult {
	public MessageInfo data;
	public AppState state;
	public Identity identity;

}
