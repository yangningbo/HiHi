package com.gaopai.guiren.bean.net;

import com.gaopai.guiren.bean.AppState;

public class AddMeetingResult {
	public AppState state;
}
