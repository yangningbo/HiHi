package com.gaopai.guiren.service;
/**
 * 
 * 功能： 聊天服务的状态 <br />
 * 日期：2013-5-30<br />
 * 地点：西竹科技<br />
 * 版本：ver 1.0<br />
 * 
 * @since
 */
public class SnsServiceType {
}
