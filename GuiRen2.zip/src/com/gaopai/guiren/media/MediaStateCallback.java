package com.gaopai.guiren.media;

public interface MediaStateCallback {
	public void onStop();
	public void onStart();
}
