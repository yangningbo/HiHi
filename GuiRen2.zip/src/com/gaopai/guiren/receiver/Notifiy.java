package com.gaopai.guiren.receiver;

import com.gaopai.guiren.bean.SNSMessage;


public interface Notifiy {
	void notifiy(SNSMessage message);
}
