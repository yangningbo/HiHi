package com.gaopai.guiren.support.view;

public class SlideViewStretch {

}
