package com.gaopai.guiren.activity.share;

public class ShareLastTalkFragment extends BaseShareFragment{

}
